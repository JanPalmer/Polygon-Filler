﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRO2_PolygonFiller
{
    public partial class Form1 : Form
    {
        public Bitmap bitmap;
        ModelVisualizer visualizer;

        public Form1()
        {
            InitializeComponent();

            bitmap = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

            //Mesh mesh = MeshCreator.CreateMeshFromObj("D:\\Studia-2022-2023-sem5\\Grafika_Komputerowa_1\\PRO2\\PRO2-PolygonFiller\\PRO2-PolygonFiller\\Objects\\Pyramid.obj");            
            Mesh mesh = MeshCreator.CreateMeshFromObj("D:\\Studia-2022-2023-sem5\\Grafika_Komputerowa_1\\PRO2\\PRO2-PolygonFiller\\PRO2-PolygonFiller\\Objects\\proj2_sfera.obj");
            string s = "";

            for (int i = 0; i < mesh.vertices.Count; i++)
            {
                //s += "V." + i + " " + mesh.vertices[i].x.ToString() + ' ' + mesh.vertices[i].y.ToString() + ' ' + mesh.vertices[i].z.ToString() + '\n';
                s += "V." + i + " " + mesh.normalVectors[i].x.ToString() + ' ' + mesh.normalVectors[i].y.ToString() + ' ' + mesh.normalVectors[i].z.ToString() + '\n';
            }
            for (int i = 0; i < mesh.faces.Count; i++)
            {
                //s += "F." + i + " " + mesh.faces[i].centerOfMass.x.ToString() + ' ' + mesh.faces[i].centerOfMass.y.ToString() + ' ' + mesh.faces[i].centerOfMass.z.ToString() + '\n';
            }


            visualizer = new ModelVisualizer(mesh);

            visualizer.FitModelOnCanvas(canvas);
            //visualizer.DrawFrame(Graphics.FromImage(bitmap));
            canvas.Invalidate();
            s += visualizer.scale + '\n';
            s += "Casts:\n";
            for (int i = 0; i < mesh.vertices.Count; i++)
            {
                s += "V." + i + " " + mesh.vertices[i].cast.X.ToString() + ' ' + mesh.vertices[i].cast.Y.ToString() + '\n';
            }
            label1.Text = s + "\nNiggers";
        }

        private void canvas_Paint(object sender, PaintEventArgs e)
        {
            visualizer.DrawFrame(e.Graphics);
        }
    }
}
