﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRO2_PolygonFiller
{
    public partial class Form1 : Form
    {
        public Bitmap bitmap;
        ModelVisualizer visualizer;
        string s = "";

        public Form1()
        {
            InitializeComponent();

            bitmap = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
            canvas.Image = bitmap;

            //Mesh mesh = MeshCreator.CreateMeshFromObj("D:\\Studia-2022-2023-sem5\\Grafika_Komputerowa_1\\PRO2\\PRO2-PolygonFiller\\PRO2-PolygonFiller\\Objects\\Pyramid.obj");            
            //Mesh mesh = MeshCreator.CreateMeshFromObj("D:\\Studia-2022-2023-sem5\\Grafika_Komp\Objects\\proj2_sfera.obj");
            Mesh mesh = MeshCreator.CreateMeshFromObj("C:\\Studia sem5\\Grafika Komputerowa 1\\PRO2\\Polygon-Filler-main\\PRO2-PolygonFiller\\PRO2-PolygonFiller\\Objects\\proj2_sfera.obj");
            //Mesh mesh = MeshCreator.CreateMeshFromObj("C:\\Studia sem5\\Grafika Komputerowa 1\\PRO2\\Polygon-Filler-main\\PRO2-PolygonFiller\\PRO2-PolygonFiller\\Objects\\Pyramid.obj");
            //Mesh mesh = MeshCreator.CreateMeshFromObj("C:\\Studia sem5\\Grafika Komputerowa 1\\PRO2\\Polygon-Filler-main\\PRO2-PolygonFiller\\PRO2-PolygonFiller\\Objects\\Rhombus.obj");


            for (int i = 0; i < mesh.vertices.Count; i++)
            {
                //s += "V." + i + " " + mesh.vertices[i].x.ToString() + ' ' + mesh.vertices[i].y.ToString() + ' ' + mesh.vertices[i].z.ToString() + '\n';
                //s += "V." + i + " " + mesh.normalVectors[i].x.ToString() + ' ' + mesh.normalVectors[i].y.ToString() + ' ' + mesh.normalVectors[i].z.ToString() + '\n';
            }

            visualizer = new ModelVisualizer(mesh);
            visualizer.FitModelOnCanvas(canvas);
            //for (int i = 0; i < mesh.vertices.Count; i++)
            //{
            //    s += "V." + i + " " + mesh.vertices[i].cast.X.ToString() + ' ' + mesh.vertices[i].cast.Y.ToString() + '\n';
            //}

            visualizer.FillFrame(bitmap, ref s);
            //visualizer.DrawFrame(Graphics.FromImage(bitmap), bitmap);
            canvas.Invalidate();
            canvas.Invalidate();
            s += visualizer.scale + '\n';
            //s += "Casts:\n";
            //for (int i = 0; i < mesh.vertices.Count; i++)
            //{
            //    s += "V." + i + " " + mesh.vertices[i].cast.X.ToString() + ' ' + mesh.vertices[i].cast.Y.ToString() + '\n';
            //}
            label1.Text = s + "\nNill";
        }

        private void canvas_Paint(object sender, PaintEventArgs e)
        {
            visualizer.DrawPolygon(e.Graphics);
        }
    }
}
