﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PRO2_PolygonFiller
{
    public class ModelVisualizer
    {
        public const int radius = 5;
        public Brush brush = Brushes.Black;
        public Pen pen = Pens.Black;
        public Mesh model;
        public float scale = 1;

        public ModelVisualizer(Mesh _model)
        {
            if (_model == null) throw new Exception();
            model = _model;
        }

        public void FitModelOnCanvas(PictureBox pictureBox)
        {
            float dx = 0, dy = 0, max;
            Vertex n, s, e, w;
            n = s = e = w = model.vertices[0];
            foreach(Vertex v in model.vertices)
            {
                if (v.y > n.y) n = v;
                if (v.x > e.x) e = v;
                if (v.x < w.x) w = v;
                if (v.y < s.y) s = v;
            }

            dx = Math.Abs(e.x - w.x);
            dy = Math.Abs(s.y - n.y);
            max = Math.Max(dx, dy);

            int canvasSize = Math.Min(pictureBox.Width, pictureBox.Height);
            scale = (float)canvasSize / max * 0.95f;
            Point canvasCenter = new Point(pictureBox.Width / 2, pictureBox.Height / 2);

            model.CastVertices(canvasCenter, scale);
        }

        public void DrawEdges(Graphics g, Face f)
        {
            if (f == null || f.vertices == null || f.vertices.Count <= 0) return;
            for (int i = 0; i < f.vertices.Count; i++)
            {
                g.DrawLine(pen, f.parent.vertices[f.vertices[i].v].cast, f.parent.vertices[f.vertices[(i + 1) % f.vertices.Count].v].cast);
            }
        }

        public void DrawVertices(Graphics g, Mesh m)
        {
            foreach (Vertex v in m.vertices)
            {
                g.FillEllipse(brush, v.cast.X - radius, v.cast.Y - radius, 2 * radius, 2 * radius);
            }
        }

        public void DrawFrame(Graphics g)
        {
            DrawVertices(g, model);
            foreach(Face f in model.faces)
            {
                DrawEdges(g, f);
            }
        }
    }
}
