﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PRO2_PolygonFiller
{
    public class ModelVisualizer
    {
        public const int radius = 5;
        public Brush brush = Brushes.Black;
        public Pen pen = Pens.Black;
        public Mesh model;
        public float scale = 1;

        public float kd, ks, m;
        public Vertex lightsource;
        public Color color_light, color_object;

        public ModelVisualizer(Mesh _model)
        {
            if (_model == null) throw new Exception();
            model = _model;
            color_light = new Color(1, 1, 1);
            color_object = new Color(1, 0, 0);
        }

        public void FitModelOnCanvas(PictureBox pictureBox)
        {
            float dx = 0, dy = 0, max;
            Vertex n, s, e, w;
            n = s = e = w = model.vertices[0];
            foreach(Vertex v in model.vertices)
            {
                if (v.y > n.y) n = v;
                if (v.x > e.x) e = v;
                if (v.x < w.x) w = v;
                if (v.y < s.y) s = v;
            }

            dx = Math.Abs(e.x - w.x);
            dy = Math.Abs(s.y - n.y);
            max = Math.Max(dx, dy);

            int canvasSize = Math.Min(pictureBox.Width, pictureBox.Height);
            scale = (float)canvasSize / max * 0.95f;
            Point canvasCenter = new Point(pictureBox.Width / 2, pictureBox.Height / 2);

            model.CastVertices(canvasCenter, scale);
            lightsource = new Vertex(w.x + 3f / 4f * e.x, 0, 1.5f);
        }

        public void DrawEdges(Graphics g, Face f)
        {
            if (f == null || f.vertices == null || f.vertices.Count <= 0) return;
            for (int i = 0; i < f.vertices.Count; i++)
            {
                g.DrawLine(pen, f.parent.vertices[f.vertices[i].v].cast, f.parent.vertices[f.vertices[(i + 1) % f.vertices.Count].v].cast);
            }
        }

        public void DrawVertices(Graphics g, Mesh m)
        {
            foreach (Vertex v in m.vertices)
            {
                g.FillEllipse(brush, v.cast.X - radius, v.cast.Y - radius, 2 * radius, 2 * radius);
            }
        }

        public struct vp
        {
            public int i;
            public int y;
        }

        public void ScanLine(Face f, Bitmap bitmap, ref string s)
        {
            vp[] P = new vp[f.vertices.Count];
            for (int k = 0; k < f.vertices.Count; k++)
            {
                P[k].i = k;
                P[k].y = f.GetVertex(k).cast.Y;
            }

            Array.Sort(P, (a, b) => a.y.CompareTo(b.y));
            int n = f.vertices.Count;
            int ymin = P[0].y;
            int ymax = P[n - 1].y;
            int i = 0;

            foreach(vp point in P)
            {
                s += $"i:{point.i}, y:{point.y}|";
            }

            List<EdgeTableNode> aet = new List<EdgeTableNode>();
            for(int y = ymin; y <= ymax; y++)
            {
                //i = 0;
                while(i < n && y - 1 == P[i].y)
                {
                    int previ = (P[i].i - 1) % n;
                    int curri = P[i].i;
                    int nexti = (P[i].i + 1) % n;
                    if (previ < 0) previ = n - 1;

                    Vertex prevV = f.GetVertex(previ);
                    Vertex currV = f.GetVertex(curri);
                    Vertex nextV = f.GetVertex(nexti);

                    if(prevV.cast.Y > currV.cast.Y)
                    {
                        float dx = currV.cast.X - prevV.cast.X;
                        float dy = currV.cast.Y - prevV.cast.Y;

                        //float dx = prevV.cast.X - currV.cast.X;
                        //float dy = prevV.cast.Y - currV.cast.Y;

                        aet.Add(new EdgeTableNode(previ, currV.cast.X, prevV.cast.Y, dx / dy));
                    }
                    
                    if(nextV.cast.Y > currV.cast.Y)
                    {
                        float dx = currV.cast.X - nextV.cast.X;
                        float dy = currV.cast.Y - nextV.cast.Y;

                        //float dx = nextV.cast.X - currV.cast.X;
                        //float dy = nextV.cast.Y - currV.cast.Y;
                        aet.Add(new EdgeTableNode(nexti, currV.cast.X, nextV.cast.Y, dx / dy));
                    }

                    if(prevV.cast.Y < currV.cast.Y)
                    {
                        aet.RemoveAll(node => node.id == curri);
                    }
                    if (nextV.cast.Y < currV.cast.Y)
                    {
                        aet.RemoveAll(node => node.id == curri);
                    }

                    i++;
                }

                //s += "AET: ";
                //foreach(EdgeTableNode node in aet)
                //{
                //    s += $"x:{node.x}, y:{node.y}|";
                //}
                //s += "\n";


                //if(i == 2)
                //Form1.ActiveForm.Text = i.ToString();

                aet.Sort((a, b) => a.x.CompareTo(b.x));

                //if(aet.Count % 2 == 0)
                for (int k = 0; k < aet.Count; k += 2)
                {
                    int startx = Math.Max((int)aet[k].x, 0);
                    int endx = (int)aet[k + 1].x;
                    while (startx <= endx)
                    {
                        bitmap.SetPixel(startx, y, Color.Red);
                        startx++;
                    }
                }

                foreach (EdgeTableNode node in aet)
                    node.x += node.m_inv;
            }

            s += $"Face {f.centerOfMass.x}, {f.centerOfMass.y} finished\n";
        }

        public void FillFrame(Bitmap bitmap,ref string s)
        {
            foreach(Face f in model.faces)
            {
                ScanLine(f, bitmap, ref s);
                s += $"Filled face {f.centerOfMass.x}, {f.centerOfMass.y}\n";
            }
        }

        public void DrawPolygon(Graphics g)
        {
            DrawVertices(g, model);
            foreach(Face f in model.faces)
            {
                DrawEdges(g, f);
            }
        }

        public void DrawFrame(Graphics g, Bitmap bitmap, ref string s)
        {
            DrawVertices(g, model);
            foreach(Face f in model.faces)
            {
                DrawEdges(g, f);
                ScanLine(f, bitmap, ref s);
            }
        }
    }
}
