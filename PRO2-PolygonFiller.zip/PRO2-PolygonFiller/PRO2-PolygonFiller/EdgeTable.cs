﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PRO2_PolygonFiller
{
    public class EdgeTableNode
    {
        public int id;
        public float y, x; // index for EdgeTable, has to be int
        public float m_inv;

        public EdgeTableNode(int _id, int _x, int _y, float _m_inv)
        {
            id = _id;
            x = _x;
            y = _y;
            m_inv = _m_inv;
        }

    }

    //public class EdgeTable
    //{
    //    //public static int height = 0;
    //    public int offset;
    //    public int Y_min = int.MaxValue;
    //    public int count;
    //    public List<EdgeTableNode>[] table;

    //    //public static void CheckMeshHighestY(Mesh m)
    //    //{
    //    //    int Y_max = 0;
    //    //    foreach(Vertex v in m.vertices)
    //    //    {
    //    //        Y_max = Math.Max(Y_max, (int)v.y);
    //    //    }
    //    //    height = Y_max;
    //    //}

    //    public EdgeTable(Face face)
    //    {
    //        offset = face.lowestY.cast.Y;
    //        table = new List<EdgeTableNode>[face.highestY.cast.Y - face.lowestY.cast.Y];
    //    }

    //    public void AddEdge(Vertex v1, Vertex v2)
    //    {
    //        EdgeTableNode e = new EdgeTableNode(v1, v2);
    //        int eY_min = Math.Min(v1.cast.Y, v2.cast.Y) - offset;

    //        if(table[eY_min] == null)
    //        {
    //            table[eY_min] = new List<EdgeTableNode>();
    //            Y_min = Math.Min(eY_min, Y_min);
    //        }
    //        table[eY_min].Add(e);
    //        count++;
    //    }

    //    public List<EdgeTableNode> ExtractElementsAt(int y)
    //    {
    //        List<EdgeTableNode> nodes = table[y - offset];
    //        if (nodes != null)
    //        {
    //            table[y] = null;
    //            count -= nodes.Count;
    //        }
    //        return nodes;
    //    }
    //}

    //public class ActiveEdgeTable
    //{
    //    List<EdgeTableNode> aet;


    //}
}
