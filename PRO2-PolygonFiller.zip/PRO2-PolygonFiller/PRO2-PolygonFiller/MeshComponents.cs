﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Drawing;

namespace PRO2_PolygonFiller
{
    public class Vertex
    {
        public float x, y, z;
        public Point cast;

        public Vertex(float _x, float _y, float _z)
        {
            x = _x;
            y = _y;
            z = _z;
        }
    }

    public class NormalVector
    {
        public float x, y, z;

        public NormalVector(float _x, float _y, float _z)
        {
            x = _x;
            y = _y;
            z = _z;
        }
        // To be written, Normalizes a vector to be of length 1
        public void Normalize() { }
    }

    public class Face
    {
        // v - index of a Vertex in its Mesh, nv - index of a Normal Vector in its Mesh
        // We assume that if a vertex has no given normal vector, its normal vector is (0, 0, 0)
        public List<(int v, int? nv)> vertices;
        public Vertex centerOfMass;
        public NormalVector centerNormalVector;
        public Mesh parent;
        public Vertex lowestY, highestY;

        public Face()
        {
            vertices = new List<(int, int?)>();
        }

        public void AddVertex(int v)
        {
            if (highestY != null && parent.vertices[v].y > highestY.y) highestY = parent.vertices[v];
            if (lowestY != null && parent.vertices[v].y < lowestY.y) lowestY = parent.vertices[v];
            vertices.Add((v, null));
        }
        public void AddVertex(int v, int nv)
        {
            if (highestY != null && parent.vertices[v].y > highestY.y) highestY = parent.vertices[v];
            if (lowestY != null && parent.vertices[v].y < lowestY.y) lowestY = parent.vertices[v];
            vertices.Add((v, nv));
        }


        public void Recalculate()
        {
            CalculateCenterOfMass();
            NormalizeVectors();
        }

        private void CalculateCenterOfMass()
        {
            float x = 0f, y = 0f, z = 0f;
            foreach((int v, int? nv) v in vertices)
            {
                x += parent.vertices[v.v].x;
                y += parent.vertices[v.v].y;
                z += parent.vertices[v.v].z;
            }

            x /= vertices.Count;
            y /= vertices.Count;
            z /= vertices.Count;

            centerOfMass = new Vertex(x, y, z);
        }

        private void NormalizeVectors()
        {
            float length, x, y, z;
            foreach((int v, int? nv) v in vertices)
            {
                if (v.nv.HasValue == false) continue;
                x = parent.normalVectors[v.nv.Value].x;
                y = parent.normalVectors[v.nv.Value].y;
                z = parent.normalVectors[v.nv.Value].z;
                length = (float)Math.Sqrt(x * x + y * y + z * z);
                parent.normalVectors[v.nv.Value].x /= length;
                parent.normalVectors[v.nv.Value].y /= length;
                parent.normalVectors[v.nv.Value].z /= length;
            }
        }
    }

    public class Mesh
    {
        public List<Vertex> vertices;
        public List<NormalVector> normalVectors;
        public List<Face> faces;

        public Mesh()
        {
            vertices = new List<Vertex>();
            normalVectors = new List<NormalVector>();
            faces = new List<Face>();
        }

        public void CastVertices(Point canvasCenter, float scale)
        {
            foreach(Vertex v in vertices)
            {
                v.cast = new Point(canvasCenter.X + (int)(v.x * scale), canvasCenter.Y + (int)(v.y * scale));
            }
        }
    }

    public static class MeshCreator
    {
        public static Mesh CreateMeshFromObj(string path)
        {
            if (!File.Exists(path)) return null;

            FileStream fs = File.OpenRead(path);
            StreamReader reader = new StreamReader(fs);

            Mesh mesh = new Mesh();

            string line;
            string[] div;

            while((line = reader.ReadLine()) != null)
            {
                div = line.Split(' ');

                switch (div[0])
                {
                    case "v":
                        mesh.vertices.Add(new Vertex(float.Parse(div[1]), float.Parse(div[2]), float.Parse(div[3])));
                        break;
                    case "vn":
                        mesh.normalVectors.Add(new NormalVector(float.Parse(div[1]), float.Parse(div[2]), float.Parse(div[3])));
                        break;
                    case "f":
                        Face tmpFace = new Face();
                        tmpFace.parent = mesh;

                        int vert, norm;
                        string[] indexString;
                        for (int i = 1; i < div.Length; i++)
                        {
                            indexString = div[i].Split('/');
                            switch (indexString.Length)
                            {
                                case 1:
                                    vert = int.Parse(indexString[0]) - 1;
                                    tmpFace.AddVertex(vert);
                                    //tmpFace.vertices.Add((vert, null));
                                    break;
                                case 3:
                                    vert = int.Parse(indexString[0]) - 1;
                                    norm = int.Parse(indexString[2]) - 1;
                                    tmpFace.AddVertex(vert, norm);
                                    //tmpFace.vertices.Add((vert, norm));
                                    break;
                                default:
                                    break;
                            }
                        }

                        tmpFace.Recalculate();
                        mesh.faces.Add(tmpFace);
                        break;
                    default:
                        break;
                }
            }

            return mesh;
        }
    }
}
